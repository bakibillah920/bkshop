<header class="header bottom-border ">
    <div class="container">
        <a href="#" class="headerLogo">
            <img class="m-auto" src="{{asset($site_info->logo)}}" alt="Logo">
        </a>
         <a class="btn btn-primary btn-lg" style="float: right;margin-top: 9px;"href="{{ url('login') }}">Login</a>
    </div>
</header>
